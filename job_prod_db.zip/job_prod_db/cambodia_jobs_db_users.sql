-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `national_id_card` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@gmail.com','pbkdf2_sha256$1000000$vvaTIUAKOzvFuVRYBsleRy$XjS+rIAzJYp1AYzbYfI75ou+nz7rv87ubobW7TXpmxY=','Super Admin','+855 12 888 999',1,'2026-10-29 03:39:48','2026-11-25 05:19:22',NULL,NULL),(8,'royalrac@gmail.com','pbkdf2_sha256$1000000$3HXs8bQ3OmZPI8v5nwChIQ$zMatdr6jWag6aVvJg2suPVmTambW1o2CxSIzmjywvVU=','RAC','0948584885',1,'2026-11-01 18:51:06','2026-11-16 15:34:24',NULL,NULL),(26,'seeker1@gmail.com','pbkdf2_sha256$1000000$CrljhLkaAwPSbWAvSg3y1b$ihAoFsNtbhZYBxxr25O3MPQmnCpOedANujvO2TBWEHo=','seeker','049995994',0,'2026-11-04 09:54:05','2026-11-18 11:16:04',NULL,NULL),(30,'laisengsok@gmail.com','pbkdf2_sha256$1000000$LDt3xWNumDgSVfJlArkry0$SV7WoxVaDFHM4Ue0JYX+fCtVnWzGvcwGuUTgwaj7fi8=','Sok Laiseng','093958344',1,'2026-11-17 16:05:00','2026-11-25 09:31:06',NULL,NULL),(31,'koyvitou@gmail.com','pbkdf2_sha256$1000000$rn0QpACLlaA8BWQH0Pc5e9$V1PyASMw+rpxLtwVg6YUp2shmBGL0H5IlkqqIAVrBaI=','Koy Vitou','061955859',1,'2026-11-17 16:15:57','2026-11-25 09:17:36',NULL,NULL),(32,'sengcg@gmail.com','pbkdf2_sha256$1000000$r5ezTdWerVnywwW2NCPZzP$fzWYLWuPrJg/yzzytrowyGYB3OKh0auG3nUp5NWF9G0=','Seng CG','09458333',1,'2026-11-17 17:03:11','2026-11-17 17:03:11',NULL,NULL),(33,'benmenghong05dm@gmail.com','pbkdf2_sha256$1000000$nmGFDP2r23jqhbkYMeHuY1$pU+grji0sswEL0LUYHxWiXSW0GoVFSll2iSB0Elv92A=','MengHong Ben',NULL,1,'2026-11-18 02:09:25','2026-11-18 02:09:25',NULL,NULL),(34,'chamroeurn980@gmail.com','pbkdf2_sha256$1000000$WHHpRsaQGNnlJTVAYGj8Eg$ry3VNDVgR+kHF0Ultsb9btzrPQR9HWVjNTfced43SL0=','Hai Chamroeurn','087 312 839',1,'2026-11-18 03:12:45','2026-11-18 03:22:31',NULL,NULL),(35,'menglong11s1024@gmail.com','pbkdf2_sha256$1000000$KcK0CP2VKdYoSjqTTGcov1$w3rsC2vKK9j+wtwQEkIKr/0ijeP1Ogf5IOY9hrqWel0=','Yim MengLong',NULL,1,'2026-11-18 06:42:57','2026-11-18 06:42:57',NULL,NULL),(36,'yolsenghou02@gmail.com','pbkdf2_sha256$1000000$Ohn2yhgsNHMh37Q8LWzsrM$vY+hJkePmiP1+hQn/T4un2QDuUVcGyaorJTm9Hgw3iw=','Yol Senghou','',1,'2026-11-18 06:44:47','2026-11-18 06:49:37',NULL,NULL),(37,'buildgrow@gamil.com','pbkdf2_sha256$1000000$9l7uqHC8waa2yeXKJiL0n1$tmbPuZBPyWF0GEHCrw+PRLCcweKH4JRYA29ndz71myA=','build &grow.CO.LTD',NULL,1,'2026-11-18 07:25:05','2026-11-25 10:27:14',NULL,NULL),(38,'vireakbuntham@gmail.com','pbkdf2_sha256$1000000$XRiTpOjTywuXR7xxx9sQja$V6nhpWcFJ4YoP0tCybYLeRFz0plBSKnCznes3tf7glw=','Vireak Buntham',NULL,1,'2026-11-18 07:46:49','2026-11-25 10:27:23',NULL,NULL),(39,'careerconnect@gmail.com','pbkdf2_sha256$1000000$yum0xBzPSAZlU1icYMrh0L$T+WBSZT8lz03o9RmVeJT43UHD/UBCVafEgMx+6cA8U0=','Career Connect',NULL,1,'2026-11-18 08:44:50','2026-11-25 10:27:31',NULL,NULL),(40,'sokna4535@gmail.com','pbkdf2_sha256$1000000$rrQkJLuMYfOWesF6iRW4cQ$9iOgJLXGLGiuKELhrpiwJBREayjwCz5/kZHjpZPL+L8=','Sok Na',NULL,1,'2026-11-25 04:20:44','2026-11-25 04:20:44',NULL,NULL),(41,'haha@gmail.com','pbkdf2_sha256$1000000$nWJSBkdgIaMSmmES4FUiNp$Gn9/SPo3OAq1byh95gQltJdyQYD5oXeBKJkOziO3nss=','Haha','089894646',1,'2026-11-25 04:26:33','2026-11-25 04:26:33',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:52
