-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seeker_profiles`
--

DROP TABLE IF EXISTS `seeker_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seeker_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `headline` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_salary` decimal(12,2) DEFAULT NULL,
  `expected_salary` decimal(12,2) DEFAULT NULL,
  `salary_currency` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `avatar_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_seeker_profiles_province` (`province`),
  CONSTRAINT `fk_seeker_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seeker_profiles`
--

LOCK TABLES `seeker_profiles` WRITE;
/*!40000 ALTER TABLE `seeker_profiles` DISABLE KEYS */;
INSERT INTO `seeker_profiles` VALUES (23,26,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD',NULL,'2026-11-04 09:54:05','2026-11-04 09:54:05'),(25,30,'បុគ្គលិក','សួរស្តី',NULL,NULL,'Phnom Penh','',NULL,NULL,2500.00,'USD',NULL,'2026-11-17 16:05:00','2026-11-18 07:10:12'),(26,32,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD',NULL,'2026-11-17 17:03:11','2026-11-17 17:03:11'),(27,33,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD','https://lh3.googleusercontent.com/a/ACg8ocJMTiVg6LCeo5d-3z6OmNNw1ygUfhxAA-r2DiLSlWEr6JKUIvkh=s96-c','2026-11-18 02:09:25','2026-11-18 02:09:25'),(28,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD',NULL,'2026-11-18 02:39:29','2026-11-18 02:39:29'),(29,34,'Developer','My name is Roeurn',NULL,NULL,'Takeo','',NULL,NULL,200.00,'USD','https://lh3.googleusercontent.com/a/ACg8ocL2MA4LhFSjpJZ0g__02bFn4AvKP0-ZvakqDVVq1xr35-r8LA=s96-c','2026-11-18 03:12:45','2026-11-18 03:22:31'),(30,35,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD','https://lh3.googleusercontent.com/a/ACg8ocKsUvt6sS3unaB13-Td4NUqTU9jU50BpwJn9lEjwsgyKkI34Dg=s96-c','2026-11-18 06:42:57','2026-11-18 06:42:57'),(31,36,'','',NULL,NULL,'Phnom Penh','',NULL,NULL,500.00,'USD','https://lh3.googleusercontent.com/a/ACg8ocJ5yaCc_1SbZ6OdAuWVGZl81jWaCML9eNaVoocIPsl_5t2PbA=s96-c','2026-11-18 06:44:47','2026-11-18 06:49:37'),(32,40,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD','https://lh3.googleusercontent.com/a/ACg8ocLEXExKaKOS6F4TZcD0gKHl-61-sZuQXS70K48T0JX0wiDlyA=s96-c','2026-11-25 04:20:44','2026-11-25 04:20:44');
/*!40000 ALTER TABLE `seeker_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:41
