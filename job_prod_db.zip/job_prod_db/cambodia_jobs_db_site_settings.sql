-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `site_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CambodiaJobs',
  `site_name_km` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ការងារកម្ពុជា',
  `site_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cambodia''s Leading Job & Recruitment Platform',
  `site_title_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'វេទិកាការងារ និងជ្រើសរើសបុគ្គលិកឈានមុខគេនៅកម្ពុជា',
  `site_subtitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Find your dream career or hire top talent across Cambodia',
  `site_subtitle_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ស្វែងរកការងារក្នុងក្តីស្រមៃ ឬជ្រើសរើសបុគ្គលិកឆ្នើមទូទាំងប្រទេសកម្ពុជា',
  `site_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `site_description_km` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Discover Verified Career Opportunities in Cambodia',
  `hero_title_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ស្វែងរកឱកាសការងារដែលបានផ្ទៀងផ្ទាត់នៅកម្ពុជា',
  `hero_subtitle` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hero_subtitle_km` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hero_badge_text` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 0xF09F87B0F09F87AD202331204A6F6220506C6174666F726D20696E2043616D626F646961,
  `hero_badge_text_km` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 0xF09F87B0F09F87AD20E19E9CE19F81E19E91E19EB7E19E80E19EB6E19E80E19EB6E19E9AE19E84E19EB6E19E9AE19E9BE19F81E19E8120E19FA120E19E93E19F85E19E80E19E98E19F92E19E96E19EBBE19E87E19EB6,
  `contact_email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'support@cambodiajobs.kh',
  `contact_phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '+855 23 999 888',
  `contact_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Phnom Penh, Cambodia',
  `contact_address_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'រាជធានីភ្នំពេញ, ប្រទេសកម្ពុជា',
  `footer_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `footer_text_km` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `social_facebook` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'https://facebook.com',
  `social_telegram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'https://t.me/CambodiaJobSupportBot',
  `social_linkedin` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'https://linkedin.com',
  `social_twitter` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `announcement_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `announcement_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `announcement_text_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `announcement_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'CambodiaJobs','ការងារកម្ពុជា','Cambodia\'s Leading Job & Recruitment Platform','វេទិកាការងារ និងជ្រើសរើសបុគ្គលិកឈានមុខគេនៅកម្ពុជា','Find Your Dream Job in Cambodia','ស្វែងរកការងារក្នុងក្តីស្រមៃរបស់អ្នកនៅកម្ពុជា','Explore thousands of verified career opportunities across Phnom Penh, Siem Reap, and all 25 provinces.','ស្វែងរកឱកាសការងាររាប់ពាន់កន្លែងដែលមានការផ្ទៀងផ្ទាត់ត្រឹមត្រូវនៅរាជធានីភ្នំពេញ សៀមរាប និងបណ្តាខេត្តទាំង២៥។','/media/site/logo_1795602291_logo_1794979944_cambo_job.png','/media/site/logo_1795602291_logo_1794979944_cambo_job.png','Find Your Dream Job in Cambodia','ស្វែងរកការងារក្នុងក្តីស្រមៃរបស់អ្នកនៅកម្ពុជា','Explore thousands of verified career opportunities across Phnom Penh, Siem Reap, and all 25 provinces.','ស្វែងរកឱកាសការងាររាប់ពាន់កន្លែងដែលមានការផ្ទៀងផ្ទាត់ត្រឹមត្រូវនៅរាជធានីភ្នំពេញ សៀមរាប និងបណ្តាខេត្តទាំង២៥។','?? #1 Job Platform in Cambodia','?? វេទិកាការងារលេខ ១ នៅកម្ពុជា','support@cambodiajobs.menghong.site','+855 23 999 888','Phnom Penh, Cambodia','រាជធានីភ្នំពេញ, ប្រទេសកម្ពុជា','Connecting ambitious professionals with reputable employers across Cambodia since 2026.','តភ្ជាប់អ្នកជំនាញដែលមានទេពកោសល្យជាមួយនិយោជកដែលគួរឱ្យទុកចិត្តទូទាំងប្រទេសកម្ពុជា។','https://facebook.com','https://t.me/CambodiaJobSupportBot','https://linkedin.com',NULL,1,'Welcome to Cambodiajob','សូមស្វាគមន៍មកកាន់ Cambodiajob','https://cambodiajob.menghong.site/','2026-11-25 10:24:52');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:51
