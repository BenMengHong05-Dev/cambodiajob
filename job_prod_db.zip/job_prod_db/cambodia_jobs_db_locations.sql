-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `province_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_km` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_km` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Phnom Penh','រាជធានីភ្នំពេញ','Khan Doun Penh','ខណ្ឌដូនពេញ'),(2,'Phnom Penh','រាជធានីភ្នំពេញ','Khan Chamkar Mon','ខណ្ឌចំការមន'),(3,'Phnom Penh','រាជធានីភ្នំពេញ','Khan Tuol Kouk','ខណ្ឌទួលគោក'),(4,'Phnom Penh','រាជធានីភ្នំពេញ','Khan Boeng Keng Kang','ខណ្ឌបឹងកេងកង'),(5,'Siem Reap','សៀមរាប','Krong Siem Reap','ក្រុងសៀមរាប'),(6,'Battambang','បាត់ដំបង','Krong Battambang','ក្រុងបាត់ដំបង'),(7,'Preah Sihanouk','ព្រះសីហនុ','Krong Preah Sihanouk','ក្រុងព្រះសីហនុ'),(8,'Kampong Cham','កំពង់ចាម','Krong Kampong Cham','ក្រុងកំពង់ចាម'),(9,'Kandal','កណ្តាល','Krong Ta Khmau','ក្រុងតាខ្មៅ'),(10,'Kampot','កំពត','Krong Kampot','ក្រុងកំពត'),(11,'Koh Kong','កោះកុង','Krong Khemara Phoumin','ក្រុងខេមរភូមិន្ទ'),(12,'Banteay Meanchey','បន្ទាយមានជ័យ','Krong Serei Saophoan','ក្រុងសិរីសោភ័ណ'),(13,'Banteay Meanchey','បន្ទាយមានជ័យ','Krong Poipet','ក្រុងប៉ោយប៉ែត'),(14,'Kampong Chhnang','កំពង់ឆ្នាំង','Krong Kampong Chhnang','ក្រុងកំពង់ឆ្នាំង'),(15,'Kampong Speu','កំពង់ស្ពឺ','Krong Chbar Mon','ក្រុងច្បារមន'),(16,'Kampong Thom','កំពង់ធំ','Krong Stueng Saen','ក្រុងស្ទឹងសែន'),(17,'Kep','កែប','Krong Kep','ក្រុងកែប'),(18,'Kratie','ក្រចេះ','Krong Kratie','ក្រុងក្រចេះ'),(19,'Mondulkiri','មណ្ឌលគិរី','Krong Senmonorom','ក្រុងសែនមនោរម្យ'),(20,'Oddar Meanchey','ឧត្តរមានជ័យ','Krong Samraong','ក្រុងសំរោង'),(21,'Pailin','ប៉ៃលិន','Krong Pailin','ក្រុងប៉ៃលិន'),(22,'Preah Vihear','ព្រះវិហារ','Krong Preah Vihear','ក្រុងព្រះវិហារ'),(23,'Prey Veng','ព្រៃវែង','Krong Prey Veng','ក្រុងព្រៃវែង'),(24,'Pursat','ពោធិ៍សាត់','Krong Pursat','ក្រុងពោធិ៍សាត់'),(25,'Ratanakiri','រតនគិរី','Krong Banlung','ក្រុងបានលុង'),(26,'Stung Treng','ស្ទឹងត្រែង','Krong Stung Treng','ក្រុងស្ទឹងត្រែង'),(27,'Svay Rieng','ស្វាយរៀង','Krong Svay Rieng','ក្រុងស្វាយរៀង'),(28,'Svay Rieng','ស្វាយរៀង','Krong Bavet','ក្រុងបាវិត'),(29,'Takeo','តាកែវ','Krong Doun Kaev','ក្រុងដូនកែវ'),(30,'Tboung Khmum','ត្បូងឃ្មុំ','Krong Suong','ក្រុងសួង');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:53
