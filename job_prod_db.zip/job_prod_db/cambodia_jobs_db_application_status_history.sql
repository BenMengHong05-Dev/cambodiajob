-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_status_history`
--

DROP TABLE IF EXISTS `application_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `application_id` int NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `changed_by` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_status_history_application` (`application_id`),
  KEY `fk_status_history_user` (`changed_by`),
  CONSTRAINT `fk_status_history_application` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_status_history_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status_history`
--

LOCK TABLES `application_status_history` WRITE;
/*!40000 ALTER TABLE `application_status_history` DISABLE KEYS */;
INSERT INTO `application_status_history` VALUES (20,80,'submitted','Candidate submitted application',30,'2026-11-17 16:37:10'),(21,80,'reviewing','Status changed to reviewing',31,'2026-11-18 05:35:42'),(22,80,'interview','Status changed to interview',31,'2026-11-18 06:21:35'),(23,81,'submitted','Candidate submitted application',33,'2026-11-18 06:25:53'),(24,81,'interview','Interview scheduled for Nov 26, 2026 10:00 AM',8,'2026-11-18 06:26:32'),(25,80,'interview','Interview scheduled for Nov 26, 2026 10:00 AM',31,'2026-11-18 06:28:38'),(26,80,'interview','Interview scheduled for Nov 26, 2026 10:00 AM',31,'2026-11-18 06:30:33'),(27,80,'interview','Interview scheduled for Nov 19, 2026 10:00 AM',31,'2026-11-18 06:34:04'),(28,82,'submitted','Candidate submitted application',36,'2026-11-18 06:56:09'),(29,82,'interview','Status changed to interview',31,'2026-11-18 07:00:08'),(30,82,'interview','Interview scheduled for Nov 19, 2026 10:00 AM',31,'2026-11-18 07:00:32'),(31,82,'shortlisted','Status changed to shortlisted',31,'2026-11-18 10:52:48'),(32,82,'interview','Status changed to interview',31,'2026-11-18 10:52:51'),(33,83,'submitted','Candidate submitted application',30,'2026-11-18 11:23:57'),(34,82,'submitted','Status changed to submitted',31,'2026-11-18 11:35:23'),(35,80,'submitted','Status changed to submitted',31,'2026-11-18 11:35:41'),(36,80,'interview','Interview scheduled for Nov 18, 2026 06:40 PM',31,'2026-11-18 11:38:29'),(37,80,'interview','Interview scheduled for Nov 18, 2026 06:40 PM',31,'2026-11-18 11:39:20'),(38,80,'interview','Status changed to interview',31,'2026-11-25 04:41:52'),(39,80,'interview','Interview scheduled for Nov 25, 2026 11:47 AM',31,'2026-11-25 04:42:43'),(40,80,'offered','Status changed to offered',31,'2026-11-25 04:55:02'),(41,82,'offered','Status changed to offered',31,'2026-11-25 05:13:45'),(42,82,'interview','Status changed to interview',31,'2026-11-25 05:14:43'),(43,82,'shortlisted','Status changed to shortlisted',31,'2026-11-25 05:14:55'),(44,81,'interview','Interview scheduled for Nov 30, 2026 02:00 PM',8,'2026-11-25 08:14:33'),(45,84,'submitted','Candidate submitted application',30,'2026-11-25 09:32:33'),(46,82,'interview','Status changed to interview',31,'2026-11-25 09:35:08'),(47,84,'interview','Status changed to interview',31,'2026-11-25 09:35:57'),(48,84,'interview','Interview scheduled for Nov 25, 2026 04:40 PM',31,'2026-11-25 09:36:18'),(49,84,'interview','Interview scheduled for Nov 25, 2026 04:45 PM',31,'2026-11-25 09:42:28'),(50,85,'submitted','Candidate submitted application',1,'2026-11-25 10:24:37'),(51,85,'reviewing','Status changed to reviewing',31,'2026-11-25 10:30:54'),(52,85,'submitted','Status changed to submitted',31,'2026-11-25 10:30:58'),(53,84,'interview','Status changed to interview',31,'2026-11-25 10:31:01'),(54,84,'interview','Interview scheduled for Nov 25, 2026 05:35 PM',31,'2026-11-25 10:32:08'),(55,84,'interview','Interview scheduled for Nov 25, 2026 05:35 PM',31,'2026-11-25 10:37:05'),(56,84,'interview','Interview scheduled for Nov 25, 2026 05:45 PM',31,'2026-11-25 10:41:11'),(57,84,'interview','Interview scheduled for Nov 25, 2026 05:50 PM',31,'2026-11-25 10:48:28'),(58,84,'interview','Interview scheduled for Nov 25, 2026 05:53 PM',31,'2026-11-25 10:50:33');
/*!40000 ALTER TABLE `application_status_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:53
