-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` int NOT NULL,
  `seeker_id` int NOT NULL,
  `resume_id` int DEFAULT NULL,
  `cover_letter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'submitted',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_application_job_seeker` (`job_id`,`seeker_id`),
  KEY `fk_applications_resume` (`resume_id`),
  KEY `idx_applications_job_id` (`job_id`),
  KEY `idx_applications_seeker_id` (`seeker_id`),
  KEY `idx_applications_status` (`status`),
  CONSTRAINT `fk_applications_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_applications_resume` FOREIGN KEY (`resume_id`) REFERENCES `resumes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_applications_seeker` FOREIGN KEY (`seeker_id`) REFERENCES `seeker_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (80,12,25,4,'Dear Hiring Manager at KV9 Cambodia Co.,Ltd,\nMy name is Sok Laiseng, and I am writing to express my interest in the Content Creator position. I have strong experience in digital video content creation, video editing, and managing social media channels. I am eager to bring my creative skills and experience to your team. Please find my attached CV for more details. Thank you for your time and consideration.','offered','2026-11-17 16:37:10','2026-11-25 04:55:02'),(81,10,27,5,'**លិខិតគ្របដណ្តប់ការងារ**\n\n**គោរពជូន គណៈគ្រប់គ្រងវិទ្យាស្ថានជាតិខេមរភាសា នៃរាជបណ្ឌិត្យសភាកម្ពុជា**\n\nខ្ញុំបាទ ម៉េងហុង ប៊ែន មានកិត្តិយសសូមដាក់ពាក្យសុំចូលរួមបម្រើការងារក្នុងតួនាទី **អ្នកអភិវឌ្ឍន៍ផ្នែកខាងក្រោយ (Backend Developer)** នៅរាជបណ្ឌិត្យសភាកម្ពុជា។ ការមើលឃើញពីបេសកកម្មរបស់ស្ថាប័នក្នុងការជំរុញវិស័យអប់រំឌីជីថលឱ្យរីកចម្រើនពាសពេញប្រទេសកម្ពុជា បានធ្វើឱ្យខ្ញុំមានការចាប់អារម្មណ៍យ៉ាងខ្លាំង ហើយខ្ញុំជឿជាក់ថាបទពិសោធន៍ និងជំនាញរបស់ខ្ញុំនឹងអាចចូលរួមចំណែកយ៉ាងមានន័យក្នុងការសម្រេចបាននូវគោលដៅនេះ។\n\nក្នុងនាមជាអ្នកជំនាញដែលមានបទពិសោធន៍ការងារផ្នែកអភិវឌ្ឍន៍កម្មវិធី ខ្ញុំមានជំនាញច្បាស់លាស់ក្នុងការបង្កើត RESTful APIs និង microservices ដែលមានស្ថិរភាពខ្ពស់ដោយប្រើប្រាស់ភាសា Python រួមជាមួយប្រព័ន្ធគ្រប់គ្រងទិន្នន័យ PostgreSQL។ ខ្ញុំត','interview','2026-11-18 06:25:53','2026-11-18 06:26:32'),(82,13,31,6,'សួរស្តីបង','interview','2026-11-18 06:56:09','2026-11-25 09:35:08'),(83,10,25,4,'**លិខិតគម្របការងារ**\n\n**គោរពជូន៖ គណៈគ្រប់គ្រងវិទ្យាស្ថានជាតិភាសាខ្មែរ នៃរាជបណ្ឌិត្យសភាកម្ពុជា**\n\n**ឈ្មោះ៖ សុខ ឡៃសេង**\n\n**ការដាក់ពាក្យសុំតួនាទី៖ Backend Developer**\n\nខ្ញុំបាទ សុខ ឡៃសេង មានកិត្តិយសយ៉ាងខ្ពង់ខ្ពស់ក្នុងការដាក់ពាក្យសុំការងារជាតួនាទី Backend Developer នៅរាជបណ្ឌិត្យសភាកម្ពុជា។ ក្នុងនាមជាបុគ្គលិកដែលមានបទពិសោធន៍ផ្នែកទីផ្សារឌីជីថល និង SEO ខ្ញុំបានឃើញយ៉ាងច្បាស់ពីសារៈសំខាន់នៃប្រព័ន្ធបច្ចេកវិទ្យាដ៏រឹងមាំ និងមានប្រសិទ្ធភាពក្នុងការជំរុញគំនិតផ្តួចផ្តើមអប់រំឌីជីថលនៅកម្ពុជា។ ខ្ញុំមានការរំភើបចិត្តយ៉ាងខ្លាំងក្នុងការចូលរួមចំណែកដល់បេសកកម្មដ៏ឧត្តុង្គឧត្តមនេះ។\n\nខ្ញុំបានបង្កើតជំនាញដ៏រឹងមាំក្នុងការវិភាគបញ្ហា ការគ្រប់គ្រងគម្រោង និងការយល់ដឹងស៊ីជម្រៅពីតម្រូវការអ្នកប្រើប្រាស់ ដែលជាមូលដ្ឋានគ្រឹះដ៏សំខាន់សម្រាប់ការអភិវ','submitted','2026-11-18 11:23:57','2026-11-18 11:23:57'),(84,13,25,4,'សូមគោរពជូនចំពោះ គណៈគ្រប់គ្រង និងក្រុមការងារជ្រើសរើសបុគ្គលិកនៃ KV9 Cambodia Co.,Ltd\n\nខ្ញុំបាទ ឈ្មោះ Sok Laiseng មានកិត្តិយសយ៉ាងខ្ពង់ខ្ពស់ក្នុងការដាក់លិខិតស្នើសុំបម្រើការងារនេះ ដើម្បីចូលរួមជាបេក្ខជនសម្រាប់មុខតំណែងជ្រើសរើសផ្នែកលក់ (Online ៤ នាក់) នៅ KV9 Cambodia Co.,Ltd។ ការសម្រេចចិត្តដាក់ពាក្យនៅក្នុងស្ថាប័នរបស់លោក/លោកស្រី គឺកើតចេញពីការជឿជាក់យ៉ាងមុតមាំថា ខ្ញុំបាទអាចរួមចំណែកជាក់ស្តែងដល់ក្រុមការងារលក់របស់ក្រុមហ៊ុន ព្រមទាំងប្តេជ្ញាចិត្តខ្ពស់ក្នុងការបំពេញតួនាទីនេះឱ្យបានល្អប្រសើរបំផុត។\n\nដោយមានជំនាញស្នូលផ្នែក Digital Marketing និង SEO រួមផ្សំនឹងបទពិសោធន៍ជាក់ស្តែងក្នុងនាទីជាបុគ្គលិក ខ្ញុំបាទមានសមត្ថភាពគ្រប់គ្រាន់ក្នុងការភ្ជាប់យុទ្ធសាស្ត្រទីផ្សារឌីជីថលទៅនឹងការលក់ផ្ទាល់តាមប្រព័ន្ធ Online ដោយអាចទាក់ទាញអតិថិជនគោលដៅ បង្កើនចំណូល និងពង្រឹងវត្តមានរបស់ក្រុមហ៊ុនលើវេទិកាអនឡាញ។ ជាពិសេស ប្រសិនបើទទួលបានឱកាសបម្រើការងារក្នុងផ្នែកលក់គ្រឿងក្រអូប ខ្ញុំបាទជឿជាក់ថានឹងអាចអនុវត្តបទពិសោធន៍ និងជំនាញដែលមាន ដើម្បីរួមចំណែកដោះស្រាយបញ្ហាការងារ និងជំរុញការអភិវឌ្ឍន៍របស់ KV9 Cambodia Co.,Ltd ឱ្យកាន់តែរីកចម្រើន។\n\nលើសពីសមត្ថភាពវិជ្ជាជីវៈ ខ្ញុំបាទយកចិត្តទុកដាក់ខ្ពស់លើក្រមសីលធម៌ការងារ ភាពស្មោះត្រង់ និងស្មារតីការងារជាក្រុម។ ខ្ញុំបាទជាអ្នកដែលមានភាពបត់បែនរហ័ស ត្រៀមខ្លួនរៀនសូត្រជាប្រចាំ និងគោរពវិន័យការងារយ៉ាងម៉ត់ចត់ ដែលជាគុណសម្បត្តិចាំបាច់សម្រាប់ការបំពេញការងារក្នុងបរិយាកាសស្ថាប័នដែលមានការប្រកួតប្រជែងខ្ពស់។\n\nខ្ញុំបាទសូមថ្លែងអំណរគុណយ៉ាងស្មោះស្ម័គ្រចំពោះគណៈគ្រប់គ្រង KV9 Cambodia Co.,Ltd ដែលបានផ្តល់ឱកាសឱ្យខ្ញុំបាទបានដាក់លិខិតនេះ។ ខ្ញុំបាទត្រៀមខ្លួនជាស្រេចក្នុងការចូលរួមសម្ភាសន៍ផ្ទាល់ ដើម្បីពិភាក្សាបន្ថែមអំពីសមត្ថភាព និងការរួមចំណែករបស់ខ្ញុំបាទចំពោះក្រុមហ៊ុន តាមកាលវេលា និងទីតាំងដែលលោក/លោកស្រីយល់ព្រម។\n\nដោយសេចក្តីគោរពដ៏ខ្ពង់ខ្ពស់,\nSok Laiseng','interview','2026-11-25 09:32:33','2026-11-25 09:35:57'),(85,12,28,8,'','submitted','2026-11-25 10:24:37','2026-11-25 10:30:58');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:42
