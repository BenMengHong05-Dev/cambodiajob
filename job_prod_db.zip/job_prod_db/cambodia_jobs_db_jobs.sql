-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_km` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_km` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `requirements` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `employment_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_time',
  `workplace_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on_site',
  `experience_level` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'entry',
  `education_level` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_min` decimal(12,2) DEFAULT NULL,
  `salary_max` decimal(12,2) DEFAULT NULL,
  `salary_currency` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `is_salary_negotiable` tinyint(1) NOT NULL DEFAULT '0',
  `vacancies_count` int NOT NULL DEFAULT '1',
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `moderation_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved',
  `published_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_jobs_category` (`category_id`),
  KEY `fk_jobs_creator` (`created_by`),
  KEY `idx_jobs_filter_main` (`status`,`moderation_status`,`province`,`category_id`),
  KEY `idx_jobs_employment_exp` (`employment_type`,`experience_level`),
  KEY `idx_jobs_salary` (`salary_min`,`salary_max`,`salary_currency`),
  KEY `idx_jobs_created_at` (`created_at` DESC),
  KEY `idx_jobs_company_id` (`company_id`),
  CONSTRAINT `fk_jobs_category` FOREIGN KEY (`category_id`) REFERENCES `job_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jobs_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jobs_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (10,4,NULL,'Backend Developer','Backend Developer','backend-developer-4-c0522d','Build resilient RESTful APIs and microservices with Python and PostgreSQL to power digital education initiatives across Cambodia.',NULL,NULL,'internship','on_site','fresh_graduate',NULL,'Siem Reap','ក្រុងសៀមរាប',NULL,320.00,400.00,'USD',0,3,'published','approved','2026-10-10 03:00:00',NULL,8,'2026-10-10 03:00:00','2026-11-18 08:39:03'),(12,9,10,'Choose a Content Creator (1 person)','ជ្រើសរើសអ្នកបង្កើតមាតិកា (១ នាក់ )','choose-a-content-creator-1-person-9-10785a','At least 1 year of experience (experience in cosmetics/fragrance sales is a plus). Good salary + other benefits.','មានបទពីសោធន៍យ៉ាងតិច១ឆ្នាំបើមានបទពិសោធន៏ខាងលក់គ្រឿងក្រអូបកាន់តែប្រសើរប្រាក់ខែល្អ + និងអត្ថប្រយោជន៏ផ្សេងៗ','At least 1 year of experience (experience in cosmetics/fragrance sales is a plus). Good salary + other benefits.','full_time','on_site','entry','bachelor','Phnom Penh','ភូមិព្រះពន្លា សង្កាត់ព្រែកប្រា ខណ្ឌច្បារអំពៅ រាជធានីភ្នំពេញ',NULL,300.00,500.00,'USD',0,1,'published','approved','2026-11-17 16:30:47',NULL,31,'2026-11-17 16:30:47','2026-11-17 16:30:47'),(13,9,3,'Online Sales Staff Wanted (4 positions)','ជ្រើសរើសផ្នែកលក់ (Online 4 នាក់)','online-sales-staff-wanted-4-positions-9-3c9b6b','At least 1 year of experience (experience in cosmetics/fragrance sales is a plus). Good salary + other benefits.','មានបទពីសោធន៍យ៉ាងតិច១ឆ្នាំបើមានបទពិសោធន៏ខាងលក់គ្រឿងក្រអូបកាន់តែប្រសើរប្រាក់ខែល្អ + និងអត្ថប្រយោជន៏ផ្សេងៗ','At least 1 year of experience (experience in cosmetics/fragrance sales is a plus). Good salary + other benefits.','full_time','on_site','entry','high_school','Phnom Penh','ភូមិព្រះពន្លា សង្កាត់ព្រែកប្រា ខណ្ឌច្បារអំពៅ រាជធានីភ្នំពេញ',NULL,200.00,400.00,'USD',0,4,'published','approved','2026-11-17 17:24:02',NULL,31,'2026-11-17 17:24:02','2026-11-17 17:24:02'),(14,10,3,'Retail Sales 1','អ្នកលក់ក្នុងហាង 1','retail-sales-1-10-84e02c','Requirements\n﻿﻿﻿Gender: No limit\n﻿﻿Age: 18-30 years old\n﻿﻿﻿Work experience: No limit','លក្ខខណ្ឌការងារ\n1. ភេទ មិនកំ់ណត់\n2. អាយុ 18-30ឆ្នាំ\n3. បទពិសោធន៍ការងារ មិនកំណត់','Gender: No limit\n﻿﻿Age: 18-30 years old\n﻿﻿﻿Work experience: No limit\n﻿﻿﻿Minimum education: High school','full_time','on_site','entry',NULL,'Phnom Penh','ខណ្ឌពោធិ៍សែនជ័យ រាជធានីភ្នំពេញ',NULL,200.00,300.00,'USD',0,1,'published','approved','2026-11-18 07:39:36',NULL,37,'2026-11-18 07:39:36','2026-11-18 07:39:36'),(15,11,6,'IT Suport','IT Support','it-suport-11-bb5988','Gender: No limit\n﻿﻿Work experience: 0-3 years\n﻿﻿Minimum education: Bachelor\n﻿﻿Other requirements: Bachelor\'s degree or diploma in Information Technology, Computer Science, or a related field.; 1-2 years of experience in IT support is preferred.; Basic knowledge of computer hardware, software, and networking.;\nAble to install, configure, and maintain computers, printers, and other IT equipment.; Able to troubleshoot hardware, software, and network issues.; Good knowledge of Windows operating systems and Microsoft Office.; Good communication, problem-solving, and troubleshooting','Gender: No limit\n﻿﻿Work experience: 0-3 years\n﻿﻿Minimum education: Bachelor\n﻿﻿Other requirements: Bachelor\'s degree or diploma in Information Technology, Computer Science, or a related field.; 1-2 years of experience in IT support is preferred.; Basic knowledge of computer hardware, software, and networking.;\nAble to install, configure, and maintain computers, printers, and other IT equipment.; Able to troubleshoot hardware, software, and network issues.; Good knowledge of Windows operating systems and Microsoft Office.; Good communication, problem-solving, and troubleshooting','Gender: No limit\n﻿﻿Work experience: 0-3 years\n﻿﻿Minimum education: Bachelor\n﻿﻿Other requirements: Bachelor\'s degree or diploma in Information Technology, Computer Science, or a related field.; 1-2 years of experience in IT support is preferred.; Basic knowledge of computer hardware, software, and networking.;\nAble to install, configure, and maintain computers, printers, and other IT equipment.; Able to troubleshoot hardware, software, and network issues.; Good knowledge of Windows operating systems and Microsoft Office.; Good communication, problem-solving, and troubleshooting skills.','full_time','on_site','entry',NULL,'Phnom Penh','រាជធានីភ្នំពេញ',NULL,300.00,500.00,'USD',0,2,'published','approved','2026-11-18 08:00:22',NULL,38,'2026-11-18 08:00:22','2026-11-18 08:00:22'),(16,12,3,'Inside Sales Executive','Inside Sales Executive','inside-sales-executive-12-8bfc54','Bachelor’s Degree in a relevant field\n\nAt least 1 year of relevant work experience\n\nGood English communication skills (speaking and writing)\n\nGood knowledge of Excel, PowerPoint, and data analysis\n\nStrong communication and teamwork skills','Bachelor’s Degree in a relevant field\n\nAt least 1 year of relevant work experience\n\nGood English communication skills (speaking and writing)\n\nGood knowledge of Excel, PowerPoint, and data analysis\n\nStrong communication and teamwork skills','Bachelor’s Degree in a relevant field\n\nAt least 1 year of relevant work experience\n\nGood English communication skills (speaking and writing)\n\nGood knowledge of Excel, PowerPoint, and data analysis\n\nStrong communication and teamwork skills','full_time','on_site','entry','bachelor','Phnom Penh','Phnom Penh · Khan Chamkar Mon Sangkat Boeng Keng Kang Ti Muoy, Phnom Penh, Cambodia',NULL,300.00,400.00,'USD',0,3,'published','approved','2026-11-18 08:51:25',NULL,39,'2026-11-18 08:51:25','2026-11-18 08:51:25'),(17,11,5,'Administrative staff','ផ្នែកមន្រ្តីរដ្ឋបាល','administrative-staff-11-333667','ប្រភេទការងារ: ពេញម៉ោង\nចំនួនជ្រើសរើស: 1 នាក់\nអត្ថប្រយោជន៍បន្ថែម៖ ប្រាក់ខែប្រកួតប្រជែង និងអត្ថប្រយោជន៍ ឱកាសអភិវឌ្ឍវិជ្ជាជីវៈ បរិយាកាសការងារដែលរួសរាយរាក់ទាក់ និងគាំទ្រ សក្តានុពលក្នុងការលូតលាស់អាជីព','ប្រភេទការងារ: ពេញម៉ោង\nចំនួនជ្រើសរើស: 1 នាក់\nអត្ថប្រយោជន៍បន្ថែម៖ ប្រាក់ខែប្រកួតប្រជែង និងអត្ថប្រយោជន៍ ឱកាសអភិវឌ្ឍវិជ្ជាជីវៈ បរិយាកាសការងារដែលរួសរាយរាក់ទាក់ និងគាំទ្រ សក្តានុពលក្នុងការលូតលាស់អាជីព','បទពិសោធន៍ការងារ: 0 3\nការអប់រំ: បរិញ្ញាបត្រ\nតម្រូវការផ្សេងទៀត៖ មានបទពិសោធន៍ផ្នែករដ្ឋបាល ឬ HR ត្រូវបានពេញចិត្ត; ជំនាញរៀបចំ និងទំនាក់ទំនងល្អ; ចំណេះដឹងមូលដ្ឋានអំពីដំណើរការ HR; មានទំនួលខុសត្រូវ, ស្មោះត្រង់ និងយកចិត្តទុកដាក់លម្អិត; អាចដោះស្រាយព័ត៌មានសម្ងាត់; ល្អក្នុង Microsoft Word / Excel; អាចធ្វើការក្រោមសម្ពាធ; មានឆន្ទៈរៀន និងរីកចម្រើនជាមួយក្រុមហ៊ុន','full_time','on_site','entry','high_school','Phnom Penh','No. 179, មហាវិថី សម្ដេចមុនីរ៉េត (217), សង្កាត់ បឹងសាឡាង, ខណ្ឌ ទួលគោក, ភ្នំពេញ 12160, កម្ពុជា',NULL,300.00,400.00,'USD',0,1,'published','approved','2026-11-18 09:34:13',NULL,38,'2026-11-18 09:34:13','2026-11-18 09:34:13');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:42
