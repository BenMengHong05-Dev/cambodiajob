-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `national_id_card` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_license_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `fk_companies_creator` (`created_by`),
  KEY `idx_companies_verification` (`verification_status`),
  CONSTRAINT `fk_companies_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (4,'Royal Academy Of Cambodia','royal-academy-of-cambodia-8','/media/companies/comp_8_1793773373_rac__1_.png','/media/companies/comp_8_1795602266_557700541_1401352571998048_8849681343401321553_n.jpg','',NULL,NULL,'201-500','Phnom Penh',NULL,NULL,'verified','2026-11-18 08:01:32',8,'2026-11-01 18:51:06','2026-11-25 10:24:26','/media/companies/comp_8_1795595994_Screenshot_2026-11-24_215948.png',NULL),(9,'KV9 Cambodia Co.,Ltd','kv9-cambodia-coltd-31','/media/companies/comp_31_1795602471_k9.jpg','/media/companies/comp_31_1795602478_617750667_1251597240170254_132436115165920733_n.jpg','<p><strong>ក្រុមហ៊ុន ខេវី៩ ខេមបូឌា មានតំណាង និងដេប៉ូ២៥ខេត្ត</strong></p>',NULL,'ទូរគមនាគមន៍','51-200','Phnom Penh',NULL,'ភូមិព្រះពន្លា សង្កាត់ព្រែកប្រា ខណ្ឌច្បារអំពៅ រាជធានីភ្នំពេញ','verified','2026-11-17 16:21:44',31,'2026-11-17 16:15:57','2026-11-25 10:28:10','/media/companies/comp_31_1795602490_profile.png',NULL),(10,'build &grow.CO.LTD','build-growcoltd-37','/media/companies/comp_37_1795602545_comp_37_1794986839_896109343_1613077523957576_1781566997309869221_n.jpg','/media/companies/comp_37_1795602549_comp_37_1794986762_906014881_1613077533957575_7276480342873424901_n.jpg','',NULL,NULL,'11-50','Phnom Penh',NULL,NULL,'verified','2026-11-18 07:28:10',37,'2026-11-18 07:25:05','2026-11-25 10:29:12','/media/companies/comp_37_1795602552_Screenshot_2026-11-24_215948.png',NULL),(11,'Vireak Buntham Express','vireak-buntham-express-38','/media/companies/comp_38_1795602526_comp_38_1794988126_913505365_1449800237314219_8756346921975433979_n.jpg','/media/companies/comp_38_1795602529_comp_38_1794988130_527214207_24117786777829958_8383707180847287971_n.jpg','',NULL,NULL,'11-50','Phnom Penh',NULL,'រាជធានីភ្នំពេញ','verified','2026-11-18 07:57:39',38,'2026-11-18 07:46:49','2026-11-25 10:28:53','/media/companies/comp_38_1795602533_Screenshot_2026-11-24_215948.png',NULL),(12,'Career Connect','career-connect-39','/media/companies/comp_39_1795602476_comp_39_1794991502_Screenshot_2026-11-18_153800.png',NULL,'',NULL,NULL,'11-50','Phnom Penh',NULL,NULL,'verified','2026-11-18 08:48:46',39,'2026-11-18 08:44:50','2026-11-25 10:28:33','/media/companies/comp_39_1795602513_Screenshot_2026-11-24_215948.png',NULL),(13,'Haha','haha-41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'rejected',NULL,41,'2026-11-25 04:26:33','2026-11-25 04:53:10',NULL,NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:43
