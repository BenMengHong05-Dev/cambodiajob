-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 116.197.154.66    Database: cambodia_jobs_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `job_categories`
--

DROP TABLE IF EXISTS `job_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_km` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_categories`
--

LOCK TABLES `job_categories` WRITE;
/*!40000 ALTER TABLE `job_categories` DISABLE KEYS */;
INSERT INTO `job_categories` VALUES (2,'Banking & Financial Services','ធនាគារ និងសេវាហិរញ្ញវត្ថុ','banking-finance','Building2'),(3,'Sales, Retail & Business Development','ការលក់ ការលក់រាយ និងអភិវឌ្ឍន៍អាជីវកម្ម','sales-marketing','TrendingUp'),(4,'Accounting & Auditing','គណនេយ្យ និងសវនកម្ម','accounting-auditing','Calculator'),(5,'Human Resources & Recruitment','ធនធានមនុស្ស និងជ្រើសរើសបុគ្គលិក','hr-recruitment','Users'),(6,'Engineering & Architecture','វិស្វកម្ម និងស្ថាបត្យកម្ម','engineering-architecture','Compass'),(7,'Education, Teaching & Training','ការអប់រំ ការបង្រៀន និងបណ្តុះបណ្តាល','education-training','GraduationCap'),(8,'Hospitality, Tourism & Catering','បដិសណ្ឋារកិច្ច ទេសចរណ៍ និងម្ហូបអាហារ','hospitality-tourism','Utensils'),(9,'Customer Support & Call Center','សេវាកម្មអតិថិជន និងមជ្ឈមណ្ឌលហៅចូល','customer-support','Headphones'),(10,'Graphic Design & Creative Media','រចនាក្រាហ្វិក និងប្រព័ន្ធផ្សព្វផ្សាយច្នៃប្រឌិត','design-media','Palette'),(11,'Healthcare, Nursing & Pharmacy','ការថែទាំសុខភាព គិលានុបដ្ឋាយិកា និងឱសថស្ថាន','healthcare-pharma','HeartPulse'),(12,'Logistics, Warehouse & Supply Chain','ភស្តុភារកម្ម ឃ្លាំង និងខ្សែច្រវាក់ផ្គត់ផ្គង់','logistics-supply','Truck');
/*!40000 ALTER TABLE `job_categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-25 18:27:53
